

const Statistics = () => {
    return (
        <div>
        <h2>Welcome to dashboard Statistics Page</h2>
        </div>
    );
};

export default Statistics;