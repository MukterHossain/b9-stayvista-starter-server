// Route
// import { createBrowserRouter } from 'react-router-dom'
// import Main from '../layouts/Main'
// import Home from '../pages/Home/Home'
// import ErrorPage from '../pages/ErrorPage'
// import Login from '../pages/Login/Login'
// import SignUp from '../pages/SignUp/SignUp'
// import RoomDetails from '../pages/RoomDetails/RoomDetails'

// export const router = createBrowserRouter([
//   {
//     path: '/',
//     element: <Main />,
    // errorElement: <ErrorPage />,
    // children: [
    //   {
    //     path: '/',
    //     element: <Home />,
    //   },
    //   {
    //     path: '/room/:id',
    //     element: <RoomDetails />,
    //   },
    // ],
//   },
  // { path: '/login', element: <Login /> },
  // { path: '/signup', element: <SignUp /> },
// ])




// Main

// import { Outlet } from 'react-router-dom'
// import Navbar from '../components/Shared/Navbar/Navbar'
// import Footer from '../components/Shared/Footer/Footer'
// const Main = () => {
//   return (
//     <div>
//       <Navbar />
//       <div className='pt-24 min-h-[calc(100vh-68px)]'>
//         <Outlet />
//       </div>
//       <Footer />
//     </div>
//   )
// }

// export default Main